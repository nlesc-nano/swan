#!/bin/bash
#SBATCH --nodes 1
#SBATCH --partition tc
#SBATCH --time 100:00:00
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=32

module load adf/2019.305 miniconda

export AMSBIN=$ADFBIN
export AMSHOME=$ADFHOME
export AMSRESOURCES=$ADFRESOURCES

source activate base


conda activate CAT
init_cat input_settings_cdft.yaml
